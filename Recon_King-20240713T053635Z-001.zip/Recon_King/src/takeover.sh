#!/bin/bash

#colors
red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
blue=`tput setaf 4`
magenta=`tput setaf 5`
reset=`tput sgr0`

read -p "Enter domain name : " DOM

if [ -d ~/recon_king/ ]
then
  echo " "
else
  mkdir ~/recon_king
fi

if [ -d ~/recon_king/$DOM ]
then
  echo " "
else
  mkdir ~/recon_king/$DOM
fi

if [ -d ~/recon_king/$DOM/Subdomain_takeovers ]
then
  echo " "
else
  mkdir ~/recon_king/$DOM/Subdomain_takeovers
fi


echo "${red}
||=================================================================================================||
||   ____  ____  __  ____  __ _  ____  _  _  __  ____    __  ____     ___  ____  ____   __  ____   ||
||  (  __)(  _ \(  )(  __)(  ( \/ ___)/ )( \(  )(  _ \  (  )/ ___)   / __)(  _ \(  __) / _\(_  _)  ||
||   ) _)  )   / )(  ) _) /    /\___ \) __ ( )(  ) __/   )( \___ \  ( (_ \ )   / ) _) /    \ )(    ||
||  (__)  (__\_)(__)(____)\_)__)(____/\_)(_/(__)(__)    (__)(____/   \___/(__\_)(____)\_/\_/(__)   || 
||                                                                                                 ||   
||=========================================== Recon_king-Viki =====================================||
${reset}"
echo "${blue} [+] Started Subdomain Takeover and S3 Bucket Takeover Scanning ${reset}"
echo " "

#nuclei
echo "${yellow} ---------------------------------- xxxxxxxx ---------------------------------- ${reset}"
echo " "
if [ -f ~/go/bin/nuclei ]
then
  echo "${magenta} [+] Running nuclei for finding potential takeovers${reset}"
  nuclei -update-templates
  nuclei -l ~/recon_king/$DOM/Subdomains/unique.txt -t ~/nuclei-templates/takeovers/ -o ~/recon_king/$DOM/Subdomain_takeovers/takeover_results.txt
else
  echo "${blue} [+] Installing nuclei ${reset}"
  go install github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
  echo "${magenta} [+] Running nuclei for finding potential takeovers${reset}"
  nuclei -update-templates
  nuclei -l ~/recon_king/$DOM/Subdomains/unique.txt -t ~/nuclei-templates/takeovers/ -o ~/recon_king/$DOM/Subdomain_takeovers/takeover_results.txt
fi

echo "${yellow} ---------------------------------- xxxxxxxx ---------------------------------- ${reset}"
echo " "
echo "${blue} [+] Successfully saved the results.txt"
echo " "
echo "${yellow} ---------------------------------- xxxxxxxx ---------------------------------- ${reset}"
echo " "
echo "${red} [+] Thank you for using Recon_king By_ViKi ${reset}"
echo ""
echo "${yellow} ---------------------------------- xxxxxxxx ---------------------------------- ${reset}"
