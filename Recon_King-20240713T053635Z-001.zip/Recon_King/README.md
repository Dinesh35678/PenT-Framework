```
 =================================================
|   ____  _____  ____ ___  _   _ _                |
|  |  _ \|___ / / ___/ _ \| \ | (_)_______ _ __   |
|  | |_) | |_ \| |  | | | |  \| | |_  / _ \ '__|  |
|  |  _ < ___) | |__| |_| | |\  | |/ /  __/ |     |
|  |_| \_\____/ \____\___/|_| \_|_/___\___|_|     |
|                                                 |
 ================= Anon-Artist ===================    
```
# About :superhero_man:
* R3C0Nizer is the first ever CLI based menu-driven automated web application B-Tier recon framework which install every tools and dependencies while running each modules so that the user need not to install any tools manually and R3C0Nizer is used to gather some assets/informations which should help you to the next step with latest updated, fastest and efficient tools. HAPPY HACKING.

# Prerequisites :grin:
- python and python3
- golang
- docker
- chromium or chromium-browser

# Usage :clinking_glasses:
```
git clone https://github.com/Anon-Artist/R3C0Nizer

cd R3C0Nizer

chmod +x reconizer.sh 

echo "export PATH=$PATH:~/go/bin" | sudo tee -a ~/.bashrc

source ~/.bashrc

./reconizer.sh
```
# Read Wiki its important

# Workflow :muscle:
![workflow](Workflow.svg)

# Expecting Contributions :monocle_face:

R3C0Nizer is expecting contributions for improving the script such as 

 - Adding more assets
 
# Demo :boom:
![Demo](demo.png)

# Contributors :star_struck:
 
* Details of Contributors:

<table>
  <tr>
    <td align="center"><a href="https://github.com/blackmarketer"><img src="https://avatars.githubusercontent.com/blackmarketer?s=100" width="100px;" alt=""/><br /><sub><b>Alan Abhilash</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/pull/1">Contributions</h6></a></td>
   <td align="center"><a href="https://github.com/E-R-R-O-R-404"><img src="https://avatars.githubusercontent.com/E-R-R-O-R-404?s=100" width="100px;" alt=""/><br /><sub><b>Vimal V</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/pull/2">Contributions</h6></a></td>
   <td align="center"><a href="https://github.com/Conscript-Security"><img src="https://avatars.githubusercontent.com/Conscript-Security?s=100" width="100px;" alt=""/><br /><sub><b>Jagan</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/pull/4">Contributions</h6></a></td>
   <td align="center"><a href="https://github.com/v1nc1d4"><img src="https://avatars.githubusercontent.com/v1nc1d4?s=100" width="100px;" alt=""/><br /><sub><b>Anurag M</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/pull/5">Contributions</h6></a></td>
   <td align="center"><a href="https://github.com/Shahul-Aboobaker"><img src="https://avatars.githubusercontent.com/Shahul-Aboobaker?s=100" width="100px;" alt=""/><br /><sub><b>Shahul Aboobaker</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/pull/11">Contributions</h6></a></td>
   <td align="center"><a href="https://github.com/GovindPalakkal"><img src="https://avatars.githubusercontent.com/GovindPalakkal?s=100" width="100px;" alt=""/><br /><sub><b>Govind Palakkal</b></sub></a><br /><h6><a href="https://github.com/Anon-Artist/R3C0Nizer/blob/main/src/blcscan.sh">Contributions</h6></a></td>
</table>

-------

***Support this project by starring ⭐, sharing 📲, and contributing 👩‍💻! :heart:***

-------
